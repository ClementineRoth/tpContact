import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-age-contact',
  templateUrl: './get-age-contact.component.html',
  styleUrls: ['./get-age-contact.component.css']
})
export class GetAgeContactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
