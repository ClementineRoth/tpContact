import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-contact',
  templateUrl: './get-contact.component.html',
  styleUrls: ['./get-contact.component.css']
})
export class GetContactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
