import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-contact',
  templateUrl: './update-contact.component.html',
  styleUrls: ['./update-contact.component.css']
})
export class UpdateContactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
