import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-article-contact',
  templateUrl: './list-article-contact.component.html',
  styleUrls: ['./list-article-contact.component.css']
})
export class ListArticleContactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
