export class Contact {
    id :number;
    pass : string;
    nom : string;
    prenom : string;
    age : string
    adresse : string
    telephone : string
}
