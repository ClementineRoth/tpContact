export class Article {
    id:number;
    marque:string;
    prix:number;
}
