import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  AUTH_SERVER= "http://localhost:5000";
  constructor(private httpClient: HttpClient) { }
}
