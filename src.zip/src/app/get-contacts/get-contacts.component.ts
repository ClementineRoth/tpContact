import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-contacts',
  templateUrl: './get-contacts.component.html',
  styleUrls: ['./get-contacts.component.css']
})
export class GetContactsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
